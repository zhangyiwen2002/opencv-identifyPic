﻿#include "widget.h"
#include "ui_widget.h"
#include "identify.h"
#include <QHostAddress>
Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    flag = "0";
    ui->setupUi(this);

    ui->label->setStyleSheet("font: 30 10pt '微软雅黑';" //字体
                                    "color: rgb(31,31,31);"		//字体颜色
                                    "padding-left:0px;"  );
    ui->label_2->setStyleSheet("font: 30 10pt '微软雅黑';" //字体
                                    "color: rgb(31,31,31);"		//字体颜色
                                    "padding-left:0px;"  );
    ui->lineEdit_ip->setStyleSheet("font: 25 10pt '微软雅黑 Light';" //字体
                                    "color: rgb(31,31,31);"		//字体颜色
                                    "padding-left:5px;"       //内边距-字体缩进
                                    "background-color: rgb(255, 255, 255);" //背景颜色
                                    "border:1px solid #8598C4;");//边框粗细-颜色-圆角设置
    ui->lineEdit_port->setStyleSheet("font: 25 10pt '微软雅黑 Light';" //字体
                                    "color: rgb(31,31,31);"		//字体颜色
                                    "padding-left:5px;"       //内边距-字体缩进
                                    "background-color: rgb(255, 255, 255);" //背景颜色
                                    "border:1px solid #8598C4;");//边框粗细-颜色-圆角设置
    ui->pushButton_open->setStyleSheet("font: 25 10pt '微软雅黑';"
                                       "border:1.5px solid #8598C4;border-radius:10px;padding:2px 4px;");
    ui->pushButton_close->setStyleSheet("font: 25 10pt '微软雅黑' ;"
                                       "border:1.5px solid #8598C4;border-radius:10px;padding:2px 4px;");
    ui->pushButton_id->setStyleSheet("font: 25 9pt '微软雅黑';"
                                     "margin-top:5px;"
                                       "border:1px solid #8598C4;border-radius:5px;padding:2px 4px;");
    ui->pushButton_id->setCursor(QCursor(Qt::PointingHandCursor));
    ui->pushButton_open->setCursor(QCursor(Qt::PointingHandCursor));
    ui->pushButton_open->setCursor(QCursor(Qt::PointingHandCursor));


    udpSocket = new QUdpSocket(this);
    udpSocket->bind(QHostAddress::Any,8888);
    udpSocket1 = new QUdpSocket(this);
    udpSocket1->bind(QHostAddress::Any,9999);
    receiver.bind(QHostAddress::Any,5556);
    connect(&fps_timer,SIGNAL(timeout()),this,SLOT(VideoSend()));
//    connect(&fps_timer,SIGNAL(timeout()),this,SLOT(sendidSignal()));
    connect(ui->pushButton_id, &QPushButton::clicked, this, &Widget::changeId);
    //显示进程B发送的图像
    connect(&receiver,SIGNAL(readyRead()),this,SLOT(video_receive_show()));
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButton_open_clicked()
{
    camera.open(0);
    fps_timer.start(33);
}

void Widget::on_pushButton_close_clicked()
{
    fps_timer.stop();
    camera.release();
    this->close();
}

void Widget::VideoSend()
{
    QHostAddress dstip = (QHostAddress)(ui->lineEdit_ip->text());
    quint16 dstport = ui->lineEdit_port->text().toInt();
    Mat frame;
    camera.read(frame);
    cvtColor(frame,frame,CV_BGR2RGB);
    QImage image((unsigned char *)(frame.data),frame.cols,frame.rows,QImage::Format_RGB888);
//    ui->label_video->setPixmap(QPixmap::fromImage(image));
//    ui->label_video->resize(image.width(),image.height());
    QByteArray byte;
    QBuffer buff(&byte);
    buff.open(QIODevice::WriteOnly);
    image.save(&buff,"JPEG");
    QByteArray ss = qCompress(byte,5);
    udpSocket->writeDatagram(ss,dstip,dstport);
}


void Widget::video_receive_show(){
    quint64 size = receiver.pendingDatagramSize();
    QByteArray buff;
    buff.resize(size);
    QHostAddress adrr ;
    quint16 port;
    receiver.readDatagram(buff.data(),buff.size(),&adrr,&port);
    buff = qUncompress(buff);
    QBuffer buffer(&buff);
    QImageReader reader(&buffer,"JPEG");//可读入磁盘文件、设备文件中的图像、以及其他图像数据如pixmap和image，相比较更加专业。
    //buffer属于设备文件一类，
    QImage image = reader.read();//read()方法用来读取设备图像，也可读取视频，读取成功返回QImage*，否则返回NULL
    ui->label_video->setPixmap(QPixmap::fromImage(image));
    ui->label_video->resize(image.width(),image.height());
}

void Widget::sendidSignal()
{
    QHostAddress dstip = (QHostAddress)(ui->lineEdit_ip->text());
    quint16 dstport = 7777;
    QByteArray byteArray = flag.toUtf8();
    QBuffer buff(&byteArray);
    buff.open(QIODevice::WriteOnly);	//缓冲区的打开方式写
//     qDebug()<<byteArray;
    udpSocket1->writeDatagram(byteArray,dstip,dstport);

}


void Widget::changeId(){
    if(flag=="0"){
        flag = "1";
        ui->pushButton_id->setText("关闭障碍物识别");
    }else{
        flag = "0";
        ui->pushButton_id->setText("开启障碍物识别");
    }
//    qDebug()<<"flag="<<flag;
    sendidSignal();
}

//void Widget::on_pushButton_id_clicked()
//{
//    sendidSignal();
//    identify *idWindow = new identify;
//    idWindow->show();
//}

void Widget::on_pushButton_open_pressed(){
    ui->pushButton_open->setStyleSheet("font: 25 10pt '微软雅黑';"
                                       "color:white;"
                                       "background:#8598C4;"
                                       "border:1.5px solid #8598C4;border-radius:10px;padding:2px 4px;");
}

void Widget::on_pushButton_open_released(){
    ui->pushButton_open->setStyleSheet("font: 25 10pt '微软雅黑';"
                                       "border:1.5px solid #8598C4;border-radius:10px;padding:2px 4px;");
}

void Widget::on_pushButton_close_pressed(){
    ui->pushButton_close->setStyleSheet("font: 25 10pt '微软雅黑';"
                                       "color:white;"
                                       "background:#8598C4;"
                                       "border:1.5px solid #8598C4;border-radius:10px;padding:2px 4px;");
}

void Widget::on_pushButton_close_released(){
    ui->pushButton_close->setStyleSheet("font: 25 10pt '微软雅黑';"
                                       "border:1.5px solid #8598C4;border-radius:10px;padding:2px 4px;");
}

void Widget::on_pushButton_id_pressed(){
    ui->pushButton_id->setStyleSheet("font: 25 9pt '微软雅黑';"
                                       "color:white;"
                                     "margin-top:5px;"
                                       "background:#8598C4;"
                                       "border:1px solid #8598C4;border-radius:5px;padding:2px 4px;");
}

void Widget::on_pushButton_id_released(){
    ui->pushButton_id->setStyleSheet("font: 25 9pt '微软雅黑';"
                                     "margin-top:5px;"
                                       "border:1px solid #8598C4;border-radius:5px;padding:2px 4px;");
}
