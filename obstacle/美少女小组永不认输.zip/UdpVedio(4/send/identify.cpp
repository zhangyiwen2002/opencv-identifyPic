#include "identify.h"
#include "ui_identify.h"

identify::identify(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::identify)
{
    ui->setupUi(this);
    ui->label->setText("图像正在识别中...");
}

identify::~identify()
{
    delete ui;
}




