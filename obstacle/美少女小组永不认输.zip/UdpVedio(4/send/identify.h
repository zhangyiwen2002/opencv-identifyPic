#ifndef IDENTIFY_H
#define IDENTIFY_H

#include <QWidget>

namespace Ui {
class identify;
}

class identify : public QWidget
{
    Q_OBJECT

public:
    explicit identify(QWidget *parent = nullptr);
    ~identify();

private slots:
//    int endidSignal();


private:
    Ui::identify *ui;
};

#endif // IDENTIFY_H
