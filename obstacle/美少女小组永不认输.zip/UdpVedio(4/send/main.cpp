#include "widget.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;

    w.setAutoFillBackground(true);
    w.setPalette(QPalette(QColor(255,255,255)));

    w.show();

    return a.exec();
}
