﻿#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QUdpSocket>
#include <QTimer>
#include <QBuffer>
#include <QPushButton>
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/types_c.h>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/features2d.hpp>
#include<QImageReader>
using namespace cv;
namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private slots:
    void on_pushButton_open_clicked();

    void on_pushButton_close_clicked();

    void VideoSend();

    void sendidSignal();

//    void on_pushButton_id_clicked();

    void changeId();

    void video_receive_show();

    void on_pushButton_open_pressed();

    void on_pushButton_open_released();

    void on_pushButton_close_pressed();

    void on_pushButton_close_released();

    void on_pushButton_id_pressed();

    void on_pushButton_id_released();


signals:
    void emit_flag(int);

private:
    Ui::Widget *ui;
    QUdpSocket *udpSocket;
    QUdpSocket *udpSocket1;
    QUdpSocket receiver;
    VideoCapture camera;
    QTimer fps_timer;
    QString flag;

};

#endif // WIDGET_H
