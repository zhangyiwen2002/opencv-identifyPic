/********************************************************************************
** Form generated from reading UI file 'identify.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_IDENTIFY_H
#define UI_IDENTIFY_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_identify
{
public:
    QLabel *label;

    void setupUi(QWidget *identify)
    {
        if (identify->objectName().isEmpty())
            identify->setObjectName(QString::fromUtf8("identify"));
        identify->resize(438, 332);
        label = new QLabel(identify);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 20, 271, 191));

        retranslateUi(identify);

        QMetaObject::connectSlotsByName(identify);
    } // setupUi

    void retranslateUi(QWidget *identify)
    {
        identify->setWindowTitle(QCoreApplication::translate("identify", "Form", nullptr));
        label->setText(QCoreApplication::translate("identify", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class identify: public Ui_identify {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_IDENTIFY_H
