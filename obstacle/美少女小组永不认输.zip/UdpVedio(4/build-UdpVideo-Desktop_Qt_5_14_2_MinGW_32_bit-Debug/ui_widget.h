/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QGridLayout *gridLayout;
    QLineEdit *lineEdit_ip;
    QLineEdit *lineEdit_port;
    QLabel *label_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_open;
    QLabel *label;
    QPushButton *pushButton_close;
    QLabel *label_video;
    QPushButton *pushButton_id;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(462, 417);
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../\346\226\207\344\273\266\345\217\221\351\200\201.png"), QSize(), QIcon::Normal, QIcon::Off);
        Widget->setWindowIcon(icon);
        gridLayout = new QGridLayout(Widget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        lineEdit_ip = new QLineEdit(Widget);
        lineEdit_ip->setObjectName(QString::fromUtf8("lineEdit_ip"));
        lineEdit_ip->setMinimumSize(QSize(0, 25));

        gridLayout->addWidget(lineEdit_ip, 0, 1, 1, 2);

        lineEdit_port = new QLineEdit(Widget);
        lineEdit_port->setObjectName(QString::fromUtf8("lineEdit_port"));
        lineEdit_port->setMinimumSize(QSize(0, 25));

        gridLayout->addWidget(lineEdit_port, 1, 1, 1, 2);

        label_2 = new QLabel(Widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMinimumSize(QSize(0, 25));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        horizontalSpacer = new QSpacerItem(186, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 5, 1, 1, 1);

        pushButton_open = new QPushButton(Widget);
        pushButton_open->setObjectName(QString::fromUtf8("pushButton_open"));
        pushButton_open->setMinimumSize(QSize(0, 27));

        gridLayout->addWidget(pushButton_open, 5, 0, 1, 1);

        label = new QLabel(Widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMinimumSize(QSize(0, 25));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        pushButton_close = new QPushButton(Widget);
        pushButton_close->setObjectName(QString::fromUtf8("pushButton_close"));
        pushButton_close->setMinimumSize(QSize(0, 27));

        gridLayout->addWidget(pushButton_close, 5, 2, 1, 1);

        label_video = new QLabel(Widget);
        label_video->setObjectName(QString::fromUtf8("label_video"));

        gridLayout->addWidget(label_video, 3, 0, 2, 2);

        pushButton_id = new QPushButton(Widget);
        pushButton_id->setObjectName(QString::fromUtf8("pushButton_id"));

        gridLayout->addWidget(pushButton_id, 3, 2, 1, 1);


        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QCoreApplication::translate("Widget", "\345\256\242\346\210\267\347\253\257", nullptr));
        lineEdit_ip->setText(QCoreApplication::translate("Widget", "192.168.1.6", nullptr));
        lineEdit_port->setText(QCoreApplication::translate("Widget", "6666", nullptr));
        label_2->setText(QCoreApplication::translate("Widget", " \347\233\256\346\240\207\347\253\257\345\217\243", nullptr));
        pushButton_open->setText(QCoreApplication::translate("Widget", "open", nullptr));
        label->setText(QCoreApplication::translate("Widget", "  \347\233\256\346\240\207ip", nullptr));
        pushButton_close->setText(QCoreApplication::translate("Widget", "close", nullptr));
        label_video->setText(QString());
        pushButton_id->setText(QCoreApplication::translate("Widget", "\345\274\200\345\220\257\351\232\234\347\242\215\347\211\251\350\257\206\345\210\253", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
