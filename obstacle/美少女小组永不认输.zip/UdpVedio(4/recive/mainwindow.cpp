﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

using namespace std;
using namespace cv;
using namespace dnn;
/*!
 * use ONNX model
 * */

void BGR2RGB(Mat bgrImg, Mat &rgbImg)
{
    rgbImg = bgrImg.clone();
    for(int i = 0;i < bgrImg.rows; i++)
    {
        for(int j = 0;j < bgrImg.cols; j++)
        {
            rgbImg.at<Vec3b>(i, j)[2] = bgrImg.at<Vec3b>(i, j)[0];
            rgbImg.at<Vec3b>(i, j)[0] = bgrImg.at<Vec3b>(i, j)[2];
        }
    }
}


Mat MainWindow::ImageToMat(const QImage& image)
{
    cv::Mat mat,mat_out;    //如果把mat_out变更为mat，那么参数image的r/b被调换。即使被const修饰，依然被更改，比较诡异。参数变为值传递，也依然被更改。
    switch (image.format())
    {
    case QImage::Format_RGB32:                              //一般Qt读入本地彩色图后为此格式
        mat = cv::Mat(image.height(), image.width(), CV_8UC4, (void*)image.constBits(), image.bytesPerLine());
        cv::cvtColor(mat, mat_out, cv::COLOR_BGRA2BGR);     //转3通道，OpenCV一般用3通道的
        break;
    case QImage::Format_RGB888:
        mat = cv::Mat(image.height(), image.width(), CV_8UC3, (void*)image.constBits(), image.bytesPerLine());
        cv::cvtColor(mat, mat_out, cv::COLOR_RGB2BGR);
        break;
    case QImage::Format_Indexed8:
        mat = cv::Mat(image.height(), image.width(), CV_8UC1, (void*)image.constBits(), image.bytesPerLine());
        break;
    }
    return mat_out;
}

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->label->setStyleSheet("font: 30 10pt '微软雅黑 Bold';" //字体
                                    "color: rgb(31,31,31);"		//字体颜色
                                    "padding-left:10px;"  );
    resize(700,600);//设置窗口大小

    flag = "0";
    udpSocket = new QUdpSocket(this);
    udpSocket->bind(QHostAddress::Any,5555);
    receiver.bind(QHostAddress::Any,6666);
    receiver1.bind(QHostAddress::Any,7777);
    connect(&receiver,SIGNAL(readyRead()),this,SLOT(video_receive_show()));
    connect(&receiver1,SIGNAL(readyRead()),this,SLOT(rcidSignals()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::video_receive_show()
{
    quint64 size = receiver.pendingDatagramSize();    
    QByteArray buff;    
    buff.resize(size);
    QHostAddress adrr ;
    quint16 port;
    receiver.readDatagram(buff.data(),buff.size(),&adrr,&port);    
    buff = qUncompress(buff);
    QBuffer buffer(&buff);
    QImageReader reader(&buffer,"JPEG");//可读入磁盘文件、设备文件中的图像、以及其他图像数据如pixmap和image，相比较更加专业。
    //buffer属于设备文件一类，
    QImage image = reader.read();//read()方法用来读取设备图像，也可读取视频，读取成功返回QImage*，否则返回NULL
    //当前进程显示
    ui->label_vid->setPixmap(QPixmap::fromImage(image));
    ui->label_vid->resize(image.width(),image.height());
//    qDebug()<<"flag="<<flag;
    //处理每一帧
    if(flag=="1"){
        // input

        std::string _model = R"(F:\\BlogResources-master\\best.onnx)";

        Yolov5 v5;
        cv::dnn::Net net;
        v5.readModel(net, _model, false);
        Mat img = ImageToMat(image);
        std::vector<Output> output;
        v5.Detect(img, net, output);

        vector<Scalar> color;
            srand(time(0));
            for (int i = 0; i < 80; i++) {
                int b = rand() % 256;
                int g = rand() % 256;
                int r = rand() % 256;
                color.push_back(Scalar(b, g, r));
            }
        img = v5.drawPred(img, output,color);


        cv::Mat Rgb;
        BGR2RGB(img, Rgb);
        image = QImage((const uchar*)(Rgb.data), Rgb.cols, Rgb.rows,
        Rgb.cols * Rgb.channels(), QImage::Format_RGB888);
        //发送回进程A
        QHostAddress dstip = (QHostAddress)"192.168.1.6";
        quint16 dstport = 5556;

        QByteArray byte;
        QBuffer bufferr(&byte);
        bufferr.open(QIODevice::WriteOnly);
        image.save(&bufferr,"JPEG");
        QByteArray ss = qCompress(byte,5);
        udpSocket->writeDatagram(ss,dstip,dstport);


    }else{
        //发送回进程A
        QHostAddress dstip = (QHostAddress)"192.168.1.6";
        quint16 dstport = 5556;

        QByteArray byte;
        QBuffer bufferr(&byte);
        bufferr.open(QIODevice::WriteOnly);
        image.save(&bufferr,"JPEG");
        QByteArray ss = qCompress(byte,5);
        udpSocket->writeDatagram(ss,dstip,dstport);


    }
//    qDebug()<<"read";



}

void MainWindow::rcidSignals()
{
    quint64 size = receiver1.pendingDatagramSize();
    QByteArray buff;
    buff.resize(size);
    QHostAddress adrr ;
    quint16 port;
    receiver1.readDatagram(buff.data(),buff.size(),&adrr,&port);
//    buff = qUncompress(buff);
    QBuffer buffer(&buff);
//    QBuffer buffer(&buff);
    flag = buff;
//    ui->textEdit->setText(flag);
//    qDebug()<<flag;
//    if(buff[0])
//    {
//        ui->label_rspsignal->setText(QString::number(buff[0]));
//    }

}
