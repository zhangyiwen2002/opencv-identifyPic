#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include<QHostAddress>
#include<QPixmap>
#include<QImageReader>
#include<QBuffer>
#include <QMainWindow>
#include <QUdpSocket>
#include <QBuffer>
#include <QPushButton>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include<opencv2/opencv.hpp>
#include<math.h>
#include <QDebug>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/imgproc/types_c.h>
#include <QLabel>
#include "yolo.h"
using namespace std;
using namespace cv;
using namespace dnn;
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    Mat ImageToMat(const QImage& image);
    ~MainWindow();


public slots:
  void video_receive_show();
  void rcidSignals();

private:
    Ui::MainWindow *ui;
    QUdpSocket *udpSocket;
    QUdpSocket receiver;
    QUdpSocket receiver1;
    QString flag;


};
#endif // MAINWINDOW_H
